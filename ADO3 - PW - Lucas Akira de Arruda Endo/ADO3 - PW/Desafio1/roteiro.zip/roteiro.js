function carregar() {
  var msg = document.getElementById("msg");
  var img = document.getElementById("imagem");
  var data = new Date();
  var hora = data.getHours();

  msg.innerHTML = `Agora são ${hora} horas.`;

  if (hora >= 0 && hora < 12) {
      img.src = "img/manhã.jpg";
      document.body.style.background = "#e2cd9f";
  } else if (hora >= 12 && hora < 18) {
      img.src = "img/tarde.jpg";
      document.body.style.background = "#d38861";
  } else {
      img.src = "img/noite.jpg";
      document.body.style.background = "#b9a3a9";
  }
}

function verificarIdade() {
  const data = new Date();
  const anoAtual = data.getFullYear();
  const anoDigitado = parseInt(document.getElementById('ano').value);
  const resultado = document.getElementById('resultado');
  const generoSelecionado = document.querySelector('input[name="radsexo"]:checked');

  if (isNaN(anoDigitado) || anoDigitado <= 0 || anoDigitado > anoAtual || !generoSelecionado) {
      resultado.innerHTML = '<p>[ERRO] Verifique os dados e tente novamente.</p>';
  } else {
      const idade = anoAtual - anoDigitado;
      const genero = generoSelecionado.id === 'masc' ? 'Homem' : 'Mulher';
      let imagemSrc;

      if (idade < 10) {
          imagemSrc = genero === 'Homem' ? 'img/bebe-homem.jpg' : 'img/bebe-mulher.jpg';
      } else if (idade < 21) {
          imagemSrc = genero === 'Homem' ? 'img/jovem-homem.jpg' : 'img/jovem-mulher.jpg';
      } else if (idade < 50) {
          imagemSrc = genero === 'Homem' ? 'img/homem-adulto.jpg' : 'img/mulher-adulta.jpg';
      } else {
          imagemSrc = genero === 'Homem' ? 'img/idoso-homem.jpg' : 'img/idosa-mulher.jpg';
      }

      resultado.innerHTML = `Detectamos ${genero} com ${idade} anos`;
      resultado.innerHTML += `<img src="${imagemSrc}" id="foto">`;
  }
}
